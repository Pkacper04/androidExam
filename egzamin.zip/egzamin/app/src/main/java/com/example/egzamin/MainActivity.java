package com.example.egzamin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int[] catsPictures = new int[]{R.drawable.kot1,R.drawable.kot2, R.drawable.kot3};

    Button prevButton;
    Button nextButton;

    EditText catSelectionEditText;

    Switch backgroundSwitch;

    ImageView catImageView;

    RelativeLayout appLayout;

    int currentPictureIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        appLayout = findViewById(R.id.appLayout);

        prevButton = findViewById(R.id.previusButton);
        nextButton = findViewById(R.id.nextButton);

        catSelectionEditText = findViewById(R.id.catEditText);

        backgroundSwitch = findViewById(R.id.backgroundSwitch);

        catImageView = findViewById(R.id.catsImageView);

        prevButton.setOnClickListener(v ->{
            selectDifferentPicture(-1);
        });

        nextButton.setOnClickListener(v -> {
            selectDifferentPicture(1);
        });

        catSelectionEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if(i == EditorInfo.IME_ACTION_DONE || i == EditorInfo.IME_ACTION_UNSPECIFIED)
                {
                    if(catSelectionEditText.getText().toString().length() != 0) {
                        int newIndex = (Integer.parseInt(catSelectionEditText.getText().toString()) - 1);
                        selectPictureByIndex(newIndex);
                    }
                    return true;
                }
                return false;
            }
        });

        backgroundSwitch.setOnCheckedChangeListener((compoundButton, b) -> {
            changeBackground(backgroundSwitch.isChecked());
        });

    }

    private void changeBackground(boolean newColor)
    {
        if(newColor)
            appLayout.setBackgroundColor(getColor(R.color.custom_blue));
        else
            appLayout.setBackgroundColor(getColor(R.color.custom_light_green));
    }

    private void selectDifferentPicture(int direction){
        currentPictureIndex += direction;

        if(currentPictureIndex < 0)
            currentPictureIndex = catsPictures.length - 1;
        else if(currentPictureIndex > catsPictures.length - 1)
        {
            currentPictureIndex = 0;
        }

        changeImage();
    }

    private void selectPictureByIndex(int newIndex){
        if(newIndex < 0 || newIndex > catsPictures.length - 1)
            return;

        currentPictureIndex = newIndex;

        changeImage();
    }

    private void changeImage(){
        catImageView.setImageResource(catsPictures[currentPictureIndex]);
    }

}